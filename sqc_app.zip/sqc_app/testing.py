####################################################################
##################QR CODE Generate##################################
####################################################################

# import qrcode
# img = qrcode.make('http://python.org')
#
# with open('qrode/'+qid, 'wb') as f:
#     img.save(f)


# img = Image.open(path)
# On successful execution of this statement,
# an object of Image type is returned and stored in img variable)

####################################################################
#############Identity Card Print####################################
####################################################################
# from PIL import Image, ImageDraw, ImageFont
#
# filename = "qrode/IDCARD.png"
# with Image.open(filename) as image:
#     width, height = image.size
#     d = ImageDraw.Draw(image)
#     fnt = ImageFont.truetype('fonts/FiraSans-Medium.otf', 14)
#     d.text((190, 115), "20168989", font=fnt, fill=(0, 0, 0))
#     d.text((190, 145), "Ajith Berlin", font=fnt, fill=(0, 0, 0))
#     d.text((190, 180), "2016311008", font=fnt, fill=(0, 0, 0))
#     d.text((230, 211), "PET", font=fnt, fill=(0, 0, 0))
#     d.text((190, 243), "ACT", font=fnt, fill=(0, 0, 0))
#
#     qrcode = Image.open("qrode/20163055.png")
#     qrcode = qrcode.resize((150, 150))
#
#     image.paste(qrcode, (350, 100))
#     d.text((390, 255), "2016311008", font=fnt, fill=(0, 0, 0))
#     image.save("idcards/image.png")
#     image.show()
# CREATE TABLE moneymanage("
#                       "id INTEGER PRIMARY KEY AUTO INCREMENT,"
#                       "name CHAR(255),"
#                       "amount INTEGER,"
#                       "withdraw INTEGER,"
#                       "deposit INTEGER,"
#                       "balance INTEGER,"
#                       "rmarks CHAR(255))
#######################################################################
##################SQL Connection#######################################
#######################################################################

import sqlite3
from sqlite3 import Error

# def sql_connection():
#     try:
#         con = sqlite3.connect('sqc_app.db')
#         return con
#     except Error:
#         print(Error)
#
#
# def sql_table(con):
#     cursorObj = con.cursor()
#     cursorObj.execute("CREATE TABLE attendance("
#                       "id INTEGER PRIMARY KEY AUTOINCREMENT,"
#                       "qid INTEGER"
#                       "name CHAR(255),"
#                       "date DATE)")
#
#     # rows = cursorObj.fetchall()
#     # for row in rows:
#     #     print(row)
#     con.commit()
#
#
# con = sql_connection()
# sql_table(con)
from spinner.waitingspinnerwidget import QtWaitingSpinner

spinner = QtWaitingSpinner(self)

spinner.setRoundness(70.0)
spinner.setMinimumTrailOpacity(15.0)
spinner.setTrailFadePercentage(70.0)
spinner.setNumberOfLines(12)
spinner.setLineLength(10)
spinner.setLineWidth(5)
spinner.setInnerRadius(10)
spinner.setRevolutionsPerSecond(1)
spinner.setColor(QColor(81, 4, 71))

spinner.start()
