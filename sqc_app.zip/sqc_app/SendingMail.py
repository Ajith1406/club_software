# Email Sender
# Mails are read from mails.txt
# Mail-Id are typed line-by-line
# If not working: Allow less secure apps- Link(https://www.google.com/settings/security/lesssecureapps)
# and also Unblock Captcha- Link(https://accounts.google.com/DisplayUnlockCaptcha)
from email.encoders import encode_base64
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email import encoders
import smtplib
import os

# Details
USERNAME = "ajithberlin08@gmail.com"
PASSWORD = "berlin1999"
FROM = '%s@gmail.com' % USERNAME


def SendEmail(TO, files, SUBJECT, MESSAGE):
    msg = MIMEMultipart('alternative')
    msg['Subject'] = SUBJECT
    me = msg['From'] = FROM
    you = msg['To'] = ', '.join(TO)
    msg.attach(MIMEText(MESSAGE))
    ################Attachment file#########################
    # if isinstance(files, dict):
    if len(files) > 0:
        for f in files.values():
            file = f.split('/')
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(open(f, "rb").read())
            part.add_header('Content-Disposition', "attachement; filename=" + file[-1])
            encode_base64(part)
            msg.attach(part)
        #########################################################

    s = smtplib.SMTP('smtp.gmail.com', 587)
    s.starttls()
    s.login(USERNAME, PASSWORD)
    s.sendmail(me, TO, msg.as_string())
    s.quit()


if __name__ == '__main__':

    with open('Ids.txt') as f, open('LogFile.txt', 'w') as o:
        MailIds = f.readlines()
        Success, Failure = '', ''
        path = "Mail_Attachments/schools.pdf"
        SUBJECT = ""
        MESSAGE = ""
        for i in MailIds:
            try:
                SendEmail([i], path, SUBJECT, MESSAGE)
                Success += i + '\n'
            except:
                Failure += i + '\n'
        o.write("Success\n%s\n\nFailure\n%s" % (Success, Failure))
        print("Success\n%s\n\nFailure\n%s" % (Success, Failure))
