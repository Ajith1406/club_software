import sqlite3
from random import randint
import qrcode
from PIL import Image, ImageDraw, ImageFont
from sqlite3 import Error



class Membership:
    """docstring for Membership"""

    def __init__(self):
        super(Membership, self).__init__()
        self.sqcAccount = {}

    def newMembership(self, entry):
        self.year = entry[4]
        self.qid = str(entry[4]) + str(randint(1000, 9999))
        if self.checkDuplicate(entry[1]):
            self.sqcAccount[self.qid] = {}
            self.sqcAccount[self.qid] = entry
            self.entryToDatabase()
            self.generateQR()
            self.createIDCard()
            self.displayDetails()
            return True
        else:
            return False

    def existingMembership(self, qid, name):
        print(self.sqcAccount)
        if qid in self.sqcAccount.keys():
            if self.sqcAccount[qid][0] == name:
                print("Your Account Details and successfully logged in")
            else:
                print("Wrong Name")
        else:
            print("Authentication failed")

    def createIDCard(self):
        filename = "qrode/IDCARD.png"
        with Image.open(filename) as image:
            width, height = image.size
            d = ImageDraw.Draw(image)
            fnt = ImageFont.truetype('fonts/FiraSans-Medium.otf', 14)
            d.text((190, 115), self.qid, font=fnt, fill=(0, 0, 0))
            d.text((190, 145), self.sqcAccount[self.qid][0], font=fnt, fill=(0, 0, 0))
            d.text((190, 180), str(self.sqcAccount[self.qid][1]), font=fnt, fill=(0, 0, 0))
            d.text((230, 211), self.sqcAccount[self.qid][2], font=fnt, fill=(0, 0, 0))
            d.text((190, 243), self.sqcAccount[self.qid][5], font=fnt, fill=(0, 0, 0))

            qrcode = Image.open('qrode/' + self.sqcAccount[self.qid][0] + "_" + self.qid + '.png')
            qrcode = qrcode.resize((150, 150))

            image.paste(qrcode, (350, 100))
            d.text((390, 255), self.qid, font=fnt, fill=(0, 0, 0))
            image.save("idcards/" + self.sqcAccount[self.qid][0] + "_" + self.qid + ".png")

    def generateQR(self):
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(self.qid)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")

        with open('qrode/' + self.sqcAccount[self.qid][0] + "_" + self.qid + '.png', 'wb') as f:
            img.save(f)

    def displayDetails(self):
        print("qid\tname\trollno\tdepartment\tdob\tyear\tcampus\tresidence\tphone")
        con = self.sql_connection()
        curserObj = con.cursor()
        curserObj.execute("SELECT qid, name, rollno, department, dob, year, campus, residence, phone FROM membership")
        rows = curserObj.fetchall()
        for row in rows:
            for val in row:
                print(val, end='\t')
            print('\n')
        con.commit()
        return rows

    @staticmethod
    def sql_connection():
        try:
            con = sqlite3.connect('sqc_app.db')
            return con
        except Error:
            print(Error)

    def entryToDatabase(self):
        con = self.sql_connection()
        todoObj = con.cursor()

        todoObj.execute("INSERT INTO membership(qid, name, rollno, department, dob, year, campus, residence, phone, "
                        "mail, interest, goal) VALUES({}, '{}',{},'{}','{}','{}', '{}','{}',{},'{}','{}','{}'"
                        ")".format(self.qid, self.sqcAccount[self.qid][0], self.sqcAccount[self.qid][1],
                                   self.sqcAccount[self.qid][2], self.sqcAccount[self.qid][3],
                                   self.sqcAccount[self.qid][4], self.sqcAccount[self.qid][5],
                                   self.sqcAccount[self.qid][6], self.sqcAccount[self.qid][7],
                                   self.sqcAccount[self.qid][8], self.sqcAccount[self.qid][9],
                                   self.sqcAccount[self.qid][10]))
        con.commit()
        # self.displayDetails()

    def checkDuplicate(self, roll):
        con = self.sql_connection()
        curserObj = con.cursor()
        curserObj.execute("SELECT qid FROM membership WHERE rollno = {}".format(roll))
        val = curserObj.fetchall()
        curserObj.execute("SELECT id FROM membership WHERE qid = {}".format(self.qid))
        dupId = curserObj.fetchall()
        con.commit()
        if len(dupId)>0:
            self.qid = str(self.year) + str(randint(1000, 9999))
            self.checkDuplicate(roll)
        if len(val) >0:
            return False
        else:
            return True

member = Membership()
# while True:
#     print("Enter 1 for Enter new membership")
#     print("Enter 2 for change existing membership")
#     print("Enter 3 for display data")
#     print("Enter 4 for exit")
#     choice = int(input())
#     if choice is 1:
#         entry = {}
#         print("Name:")
#         entry[0] = input()
#         print("Roll No:")
#         entry[1] = int(input())
#         print("Department:")
#         entry[2] = input()
#         print("DoB:")
#         entry[3] = input()
#         print("year")
#         entry[4] = int(input())
#         print("Campus:")
#         entry[5] = input()
#         print("Enter residance:")
#         entry[6] = input()
#         print("Phone No")
#         entry[7] = int(input())
#         print("Mail ID")
#         entry[8] = input()
#         print("Area of Interest:")
#         entry[9] = input()
#         print("Future Goal:")
#         entry[10] = input()
#         member.newMembership(entry)
#     elif choice is 2:
#         print("Enter Q ID:")
#         qid = input()
#         print("Enter Your Name:")
#         name = input()
#         member.existingMembership(qid, name)
#     elif choice is 3:
#         member.displayDetails()
#     else:
#         quit()
