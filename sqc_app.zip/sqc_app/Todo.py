import sqlite3
from datetime import date, datetime
from sqlite3 import Error

from win32timezone import now


class Todo:
    def __init__(self):
        self.diplayData()

    @staticmethod
    def sql_connection():
        try:
            con = sqlite3.connect('sqc_app.db')
            return con
        except Error:
            print(Error)

    def insertData(self, entities):
        con = self.sql_connection()
        todoObj = con.cursor()

        todoObj.execute("INSERT INTO todo(todo,  file, description, time) VALUES(?, ?, ?, date('now'))", entities)
        con.commit()
        # self.diplayData()
        return True

    def deleteData(self, id):
        con = self.sql_connection()
        todoObj = con.cursor()

        todoObj.execute("DELETE FROM todo WHERE id={}".format(id))
        con.commit()
        self.diplayData()
        return True

    def updateData(self, id, entities):
        con = self.sql_connection()
        todoObj = con.cursor()

        todoObj.execute('UPDATE todo SET todo = "{}", file = "{}", description="{}" where id = '
                        '{}'.format(entities[0], entities[1], entities[2], id))
        con.commit()
        return True

    def clearData(self):
        con = self.sql_connection()
        todoObj = con.cursor()

        todoObj.execute('DELETE FROM todo')
        con.commit()
        return True

    def sendNotification(self):
        pass

    def diplayData(self):
        con = self.sql_connection()
        todoObj = con.cursor()
        todoObj.execute("SELECT id,file,todo,description,time FROM todo ORDER BY id DESC")
        rows = todoObj.fetchall()
        con.commit()
        return rows

    def pretty_date(time=False):
        """
        Get a datetime object or a int() Epoch timestamp and return a
        pretty string like 'an hour ago', 'Yesterday', '3 months ago',
        'just now', etc
        """
        now = datetime.now()
        if type(time) is int:
            diff = now - datetime.fromtimestamp(time)
        elif isinstance(time, datetime):
            diff = now - time
        elif not time:
            diff = now - now
        second_diff = diff.seconds
        day_diff = diff.days

        if day_diff < 0:
            return ''

        if day_diff == 0:
            if second_diff < 10:
                return "just now"
            if second_diff < 60:
                return str(second_diff) + " seconds ago"
            if second_diff < 120:
                return "a minute ago"
            if second_diff < 3600:
                return str(second_diff / 60) + " minutes ago"
            if second_diff < 7200:
                return "an hour ago"
            if second_diff < 86400:
                return str(second_diff / 3600) + " hours ago"
        if day_diff == 1:
            return "Yesterday"
        if day_diff < 7:
            return str(day_diff) + " days ago"
        if day_diff < 31:
            return str(day_diff / 7) + " weeks ago"
        if day_diff < 365:
            return str(day_diff / 30) + " months ago"
        return str(day_diff / 365) + " years ago"


todo = Todo()
# while True:
#     print("Enter 1 to add data")
#     print("Enter 2 to delete data")
#     print("Enter 3 to update data")
#     print("Enter 4 to clear data")
#     print("Enter 5 to display data")
#     print("Enter 6 to send Notification")
#     print("Enter 7 to Quit")
#     choice = int(input())
#
#     if choice is 1:
#         entities = ('WFH', 'do project', 'no file')
#         todo.insertData(entities)
#     elif choice is 2:
#         todo.diplayData()
#         print("please enter the id want to delete")
#         id = input()
#         todo.deleteData(id)
#     elif choice is 3:
#         todo.diplayData()
#         print("please enter the id")
#         id = input()
#         print("what do you want to update")
#         key = input()
#         print("enter updated detail")
#         value = input()
#         todo.updateData(id, key, value)
#     elif choice is 4:
#         todo.clearData()
#     elif choice is 5:
#         todo.diplayData()
#     elif choice is 6:
#         print("This function will come soon")
#     elif choice is 7:
#         quit()
