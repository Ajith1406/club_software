import sqlite3

from sqlite3 import Error


class Connection:
    @staticmethod
    def sql_connection():
        try:
            con = sqlite3.connect('sqc_app.db')
            return con
        except Error:
            print(Error)

    def createTables(self):
        con = self.sql_connection()
        todoObj = con.cursor()
        todoObj.execute("CREATE TABLE attendance ( id	INTEGER PRIMARY KEY AUTOINCREMENT,qid	INTEGER, name CHAR(255),date	DATE,	department	TEXT,"
                        ");"
                        "CREATE TABLE membership ("
                        "id	INTEGER PRIMARY KEY AUTOINCREMENT,"
                        "qid	INTEGERname CHAR(255),"
                        "	rollno	INTEGER,"
                        "	department	CHAR(255),"
                        "	dob	DATE,"
                        "	year	INTEGER,"
                        "	campus	CHAR(255),"
                        "	residence	CHAR(255),"
                        "	phone	INTEGER,"
                        "	mail	VARCHAR(255),"
                        "	interest	TEXT,"
                        "	goal	TEXT,"
                        "	name	TEXT);"
                        "CREATE TABLE moneymanage ("
                        "	id	INTEGER PRIMARY KEY AUTOINCREMENT,"
                        "	name	CHAR(255),"
                        "	withdraw	INTEGER,"
                        "	deposit	INTEGER,"
                        "	balance	INTEGER,"
                        "remarks	CHAR(255),"
                        "date	DATE);"
                        "CREATE TABLE sqc_database ("
                        "id	INTEGER PRIMARY KEY AUTOINCREMENT,"
                        "name	CHAR(255),"
                        "source	CHAR(255),"
                        "phone	INTEGER,"
                        "mail	VARCHAR(255),"
                        "address	VARCHAR,"
                        "place	CHAR(255),"
                        "category	CHAR(255),"
                        "note	CHAR(255));"
                        "CREATE TABLE todo ("
                        "id	INTEGER PRIMARY KEY AUTOINCREMENT,"
                        "	todo	varchar(255),"
                        "	description	varchar(255),"
                        "	file	char(255),"
                        "	time	DATE"
                        ")")
        con.commit()
database = Connection()
database.createTables()