import sqlite3

from sqlite3 import Error


# def enterDetails(choice):
#     print("Enter Name")
#     name = input()
#     print("Enter Source")
#     source = input()
#     print("Enter Address")
#     address = input()
#     print("Enter Place")
#     place = input()
#     print("Any Note")
#     note = input()
#     if choice is not 6:
#         print("Enter Phone No.")
#         phone = int(input())
#         print("Enter Mail ID")
#         mail = input()
#         return [name, source, phone, mail, address, place, note]
#     return [name, source, address, place, note]


class SqcDatabase:
    def collegeDetails(self, entities):
        con = self.sql_connection()
        todoObj = con.cursor()

        todoObj.execute("INSERT INTO sqc_database(name, source, phone, mail, address, place, category, note)"
                        " VALUES('{}', '{}', {}, '{}', '{}', '{}', 'college', '{}')".
                        format(entities[0], entities[1], entities[2], entities[3], entities[4], entities[5],
                               entities[6]))
        con.commit()
        return True

    def companyDetails(self, entities):
        con = self.sql_connection()
        todoObj = con.cursor()

        todoObj.execute("INSERT INTO sqc_database(name, source, phone, mail, address, place, category, note)"
                        " VALUES('{}', '{}', {}, '{}', '{}', '{}', 'company', '{}')".
                        format(entities[0], entities[1], entities[2], entities[3], entities[4], entities[5],
                               entities[6]))
        con.commit()
        return True

    def courseContacts(self, entities):
        con = self.sql_connection()
        todoObj = con.cursor()

        todoObj.execute("INSERT INTO sqc_database(name, source, phone, mail, address, place, category, note)"
                        " VALUES('{}', '{}', {}, '{}', '{}', '{}', 'autvs', '{}')".
                        format(entities[0], entities[1], entities[2], entities[3], entities[4], entities[5],
                               entities[6]))
        con.commit()
        return True

    def schoolsDetails(self, entities):
        con = self.sql_connection()
        todoObj = con.cursor()

        todoObj.execute("INSERT INTO sqc_database(name, source, phone, mail, address, place, category, note)"
                        " VALUES('{}', '{}', {}, '{}', '{}', '{}', 'school', '{}')".
                        format(entities[0], entities[1], entities[2], entities[3], entities[4], entities[5],
                               entities[6]))
        con.commit()
        return True

    def annaUniversity(self, entities):
        con = self.sql_connection()
        todoObj = con.cursor()

        todoObj.execute("INSERT INTO sqc_database(name, source, phone, mail, address, place, category, note)"
                        " VALUES('{}', '{}', {}, '{}', '{}', '{}', 'Anna University', '{}')".
                        format(entities[0], entities[1], entities[2], entities[3], entities[4], entities[5],
                               entities[6]))
        con.commit()
        return True

    def files(self, entities):
        con = self.sql_connection()
        todoObj = con.cursor()

        todoObj.execute("INSERT INTO sqc_database(name, source, phone, mail, address, place, category, note)"
                        " VALUES('{}', '{}', 0, '-', '{}', '{}', 'file', '{}')".
                        format(entities[0], entities[1], entities[2], entities[3], entities[4]))
        con.commit()
        return True

    @staticmethod
    def sql_connection():
        try:
            con = sqlite3.connect('sqc_app.db')
            return con
        except Error:
            print(Error)

    def displayDetails(self, category):
        con = self.sql_connection()
        todoObj = con.cursor()
        todoObj.execute("SELECT * FROM sqc_database WHERE category = '{}'".format(category))
        rows = todoObj.fetchall()
        for row in rows:
            print(row)
        con.commit()
        return rows

    def mailImport(self, category):
        con = self.sql_connection()
        todoObj = con.cursor()
        todoObj.execute("SELECT mail FROM sqc_database WHERE category = '{}'".format(category))
        rows = todoObj.fetchall()
        for row in rows:
            print(row)
        con.commit()
        return rows


entry = SqcDatabase()
# while True:
#     print("Enter 1 to input college Details")
#     print("Enter 2 to input company Details")
#     print("Enter 3 to input school Details")
#     print("Enter 4 to input Anna University Details")
#     print("Enter 5 to input AU TVS contact Details")
#     print("Enter 6 to view Details")
#     print("Enter 7 to quit")
#     choice = int(input())
#     if choice < 6:
#         entities = enterDetails(choice)
#     if choice is 1:
#         entry.collegeDetails(entities)
#     elif choice is 2:
#         entry.companyDetails(entities)
#     elif choice is 3:
#         entry.schoolsDetails(entities)
#     elif choice is 4:
#         entry.annaUniversity(entities)
#     elif choice is 5:
#         entry.files(entities)
#     elif choice is 6:
#         entry.displayDetails()
#     elif choice is 7:
#         quit()
