import sqlite3

import cv2
import pyzbar.pyzbar as pyzbar
import time
from sqlite3 import Error


##############SQL Connection#################
def sql_connection():
    try:
        con = sqlite3.connect('sqc_app.db')
        return con
    except Error:
        print(Error)


# starting the webcam using opencv
cap = cv2.VideoCapture(0)

fob = open('attendence.csv', 'a')
# fob.write("QID,Name,Department,Time\n")

qids = []
present = {}


# function for writing the data into text file
def attendaceEntry(data):
    con = sql_connection()
    todoObj = con.cursor()
    todoObj.execute("INSERT INTO attendance(qid, name, department, date) VALUES(?, ?, ?, date('now'))", data[0])
    con.commit()


def searchData(z):
    try:
        con = sql_connection()
        todoObj = con.cursor()
        todoObj.execute("SELECT qid, name, department FROM membership WHERE qid={}".format(z))
        val = todoObj.fetchall()
        return val
    except:
        print("you are mot registered")


def enterData(z, data):
    fob = open('attendence.csv', 'a')
    if z in qids:
        pass
    else:
        qids.append(z)
        z = ''.join(str(z))
        for datum in data:
            for val in datum:
                fob.write(str(val) + ',')
            fob.write(str(time.ctime()))
            fob.write('\n')
        return qids
    fob.close()


print('Reading...')


# function for check the data is present or not
def checkData(data):
    data = str(data)
    if data in qids:
        print('Already Present')
        return 0
    else:
        print('\n' + str(len(qids) + 1) + '\n' + data)
        d = searchData(data)
        if len(d) is not 0:
            attendaceEntry(d)
            present[data] = d
            enterData(data, d)
            return 1
        else:
            print("Not Register")
            return 2


def startVideo():
    while True:
        _, frame = cap.read()
        decodedObjects = pyzbar.decode(frame)
        for obj in decodedObjects:
            checkData(int(obj.data))
            time.sleep(1)

        cv2.imshow("Frame", frame)

        # closing the program when s is pressed
        if cv2.waitKey(1) & 0xFF == ord('s'):
            cv2.destroyAllWindows()
            break


fob.close()
