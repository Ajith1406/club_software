import sqlite3

from sqlite3 import Error


class MoneyManager:
    def __init__(self):
        con = self.sql_connection()
        cursorObj = con.cursor()
        cursorObj.execute("SELECT balance FROM moneymanage ORDER BY id DESC LIMIT 1")
        bal = cursorObj.fetchone()
        if bal is None:
            self.account = 0
        else:
            self.account = bal[0]
        con.commit()
        self.balance()

    def addMoney(self, name, money, remarks):
        self.account += money
        con = self.sql_connection()
        todoObj = con.cursor()

        todoObj.execute("INSERT INTO moneymanage(name, withdraw, deposit, balance, remarks, date)"
                        " VALUES('{}', {}, {}, {}, '{}', date('now'))".format(name, 0, money, self.account, remarks))
        con.commit()
        return True

    def withdrawMoney(self, name, money, remarks):
        self.account -= money
        con = self.sql_connection()
        todoObj = con.cursor()

        todoObj.execute("INSERT INTO moneymanage(name, withdraw, deposit, balance, remarks, date)"
                        " VALUES('{}', {}, {}, {}, '{}', date('now'))".format(name, money, 0, self.account, remarks))
        con.commit()
        return True

    def balance(self):
        con = self.sql_connection()
        todoObj = con.cursor()
        todoObj.execute("SELECT balance FROM moneymanage order by id desc LIMIT 1")
        rows = todoObj.fetchall()
        # for row in rows:
        #     print(row[0])
        con.commit()
        return rows[0][0]

    def printHistory(self):
        con = self.sql_connection()
        todoObj = con.cursor()
        todoObj.execute("SELECT date, name, withdraw, deposit, balance, remarks FROM moneymanage")
        rows = todoObj.fetchall()
        con.commit()
        return rows

    @staticmethod
    def sql_connection():
        try:
            con = sqlite3.connect('sqc_app.db')
            return con
        except Error:
            print(Error)


account = MoneyManager()
# while True:
#     print("Enter 1 to add Money")
#     print("Enter 2 to withdraw Money")
#     print("Enter 3 to view Balance Money")
#     print("Enter 4 to print history")
#     print("Enter 5 to Exit")
#     choice = int(input())
#     if choice is 1:
#         print("enter the name of depositor")
#         name = input()
#         print("Enter amount to add account")
#         money = int(input())
#         print("Enter remarks")
#         remarks = input()
#         account.addMoney(name, money, remarks)
#     elif choice is 2:
#         print("enter the name of withdrawal")
#         name = input()
#         print("Enter amount to withdraw account")
#         money = int(input())
#         print("Enter remarks")
#         remarks = input()
#         account.withdrawMoney(name, money, remarks)
#     elif choice is 3:
#         account.balance()
#     elif choice is 4:
#         print("this function will add soon")
#     elif choice is 5:
#         quit()