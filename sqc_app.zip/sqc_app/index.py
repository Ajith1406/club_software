import shutil
import sys
import time
import webbrowser

import cv2
from PyQt5.QtCore import QFileInfo, QRect
from PyQt5.QtGui import QPixmap, QIcon
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox, QFileDialog, QTableWidgetItem
from PyQt5.uic import loadUiType
from pyzbar import pyzbar

from membership import member
import SendingMail
import Attendence
from MoneyManager import account
from Todo import todo

ui, _ = loadUiType('ui/home.ui')


class MainApp(QMainWindow, ui):
    def __init__(self, parent=None):
        super(MainApp, self).__init__(parent)
        QMainWindow.__init__(self)
        self.att = {}
        self.setupUi(self)
        self.InitUI()
        self.Handle_Button()

    def InitUI(self):
        self.comboBox.addItem('Hosteler')
        self.comboBox.addItem('Dayscholor')
        self.tabWidget.tabBar().setVisible(0)
        self.lcdNumber.display(account.balance())
        self.todoDisplay()

    def Handle_Button(self):
        ####################Navigation Button####################
        self.pushButton_111.clicked.connect(self.openHome)
        self.pushButton_112.clicked.connect(self.openMembership)
        self.pushButton_113.clicked.connect(self.openSendMails)
        self.pushButton_114.clicked.connect(self.openBank)
        self.pushButton_115.clicked.connect(self.openAttendance)
        self.pushButton_116.clicked.connect(self.openTodo)
        self.pushButton_117.clicked.connect(self.openDatabase)
        self.pushButton_118.clicked.connect(self.openSettings)

        ####################Membership############################
        self.pushButton_3.clicked.connect(self.membershipRegister)
        self.pushButton.clicked.connect(self.membershipSendMail)
        self.pushButton_2.clicked.connect(self.membershipClear)

        ###################Sending Mail App#######################
        self.pushButton_4.clicked.connect(self.attachmentBrowse)
        self.pushButton_5.clicked.connect(self.sendMails)
        self.pushButton_6.clicked.connect(self.linkDetails_1)
        self.pushButton_7.clicked.connect(self.linkDetails_2)
        self.pushButton_9.clicked.connect(self.clearMail)

        #####################Attendance##########################
        self.pushButton_8.clicked.connect(self.startAttendance)
        self.pushButton_10.clicked.connect(self.typeQid)
        self.pushButton_11.clicked.connect(self.closeCamera)
        self.pushButton_12.clicked.connect(self.resetAtt)
        self.pushButton_13.clicked.connect(self.printCSV)

        ####################Money Manage#########################
        self.pushButton_14.clicked.connect(self.enterData)
        self.pushButton_15.clicked.connect(self.printHistory)
        self.pushButton_18.clicked.connect(self.clearMoney)

        ###################TODO_APP#####################
        self.pushButton_17.clicked.connect(self.todoData)
        self.pushButton_16.clicked.connect(self.todoAction)

        ##################Money Manage##########################
        self.pushButton_35.clicked.connect(self.uploadData)
        self.pushButton_37.clicked.connect(self.clearDatabaseWin)
        self.pushButton_36.clicked.connect(self.downloadDatabase)
        self.pushButton_38.clicked.connect(self.importMailIds)

        #################Home Tab################################
        self.pushButton_19.clicked.connect(self.openMembership)
        self.pushButton_21.clicked.connect(self.openSendMails)
        self.pushButton_20.clicked.connect(self.openBank)
        self.pushButton_23.clicked.connect(self.openAttendance)
        self.pushButton_24.clicked.connect(self.openTodo)
        self.pushButton_22.clicked.connect(self.openDatabase)
        self.pushButton_25.clicked.connect(self.openSettings)

        ###################Theme Buttons########################
        self.pushButton_119.clicked.connect(self.applyClassic)
        self.pushButton_120.clicked.connect(self.applyDarkBlue)
        self.pushButton_121.clicked.connect(self.applyDarkGrey)
        self.pushButton_122.clicked.connect(self.applyDark)

        self.pushButton_26.clicked.connect(self.sendQuery)

    ###########Sending Query#################################
    def sendQuery(self):
        try:
            msg = self.plainTextEdit_4.toPlainText()
            sub = "QUERY ABOUT SQC APP"
            to = 'ajithberlin09@gmail.com'
            SendingMail.SendEmail(to, [], sub, msg)
            QMessageBox.information(self, "Sent", "Query Sent Successfully")
        except:
            QMessageBox.warning(self, "Sorry", "Query Wasn't sent")

    #######################Theme Guide##########################
    def applyClassic(self):
        style = open('theme/classic', 'r')
        style = style.read()
        self.setStyleSheet(style)

    def applyDarkBlue(self):
        style = open('theme/dark_blue', 'r')
        style = style.read()
        self.setStyleSheet(style)

    def applyDarkGrey(self):
        style = open('theme/dark_grey', 'r')
        style = style.read()
        self.setStyleSheet(style)

    def applyDark(self):
        style = open('theme/dark', 'r')
        style = style.read()
        self.setStyleSheet(style)

    #######################Navigation GUI#######################
    def openHome(self):
        self.tabWidget.setCurrentIndex(0)

    def openMembership(self):
        self.tabWidget.setCurrentIndex(1)

    def openSendMails(self):
        self.tabWidget.setCurrentIndex(2)

    def openBank(self):
        self.tabWidget.setCurrentIndex(3)

    def openAttendance(self):
        self.tabWidget.setCurrentIndex(4)

    def openTodo(self):
        self.tabWidget.setCurrentIndex(5)

    def openDatabase(self):
        self.tabWidget.setCurrentIndex(6)

    def openSettings(self):
        self.tabWidget.setCurrentIndex(7)

    ######################APPLY THEME##########################
    # def darkGrey(self):
    #     style = open('','r')
    #     style= style.read()
    #     self.setStyleSheet(style)
    ######################SQC DataBase#########################
    def uploadData(self):
        choice = self.comboBox_4.currentIndex()
        if choice is 0:
            QMessageBox.warning(self, "choose category", "You must choose category")
        elif choice is not 5:
            entities = [self.lineEdit_28.text(),  # name
                        self.lineEdit_23.text(),  # source
                        self.lineEdit_26.text(),  # phone
                        self.lineEdit_27.text(),  # mail
                        self.plainTextEdit_7.toPlainText(),  # address
                        self.lineEdit_25.text(),  # place
                        self.plainTextEdit_8.toPlainText()]  # note
            if '' in entities:
                QMessageBox.warning(self, "Alert", "Enter all Data")
            else:
                if choice is 1:
                    if entry.annaUniversity(entities):
                        QMessageBox.information(self, "Success", "Database added successfully")
                    else:
                        QMessageBox.warning(self, "Failed", "Database adding is failed")
                elif choice is 2:
                    if entry.collegeDetails(entities):
                        QMessageBox.information(self, "Success", "Database added successfully")
                    else:
                        QMessageBox.warning(self, "Failed", "Database adding is failed")
                elif choice is 3:
                    if entry.companyDetails(entities):
                        QMessageBox.information(self, "Success", "Database added successfully")
                    else:
                        QMessageBox.warning(self, "Failed", "Database adding is failed")
                elif choice is 4:
                    if entry.courseContacts(entities):
                        QMessageBox.information(self, "Success", "Database added successfully")
                    else:
                        QMessageBox.warning(self, "Failed", "Database adding is failed")
                elif choice is 6:
                    if entry.schoolsDetails(entities):
                        QMessageBox.information(self, "Success", "Database added successfully")
                    else:
                        QMessageBox.warning(self, "Failed", "Database adding is failed")
        else:
            entities = [self.lineEdit_28.text(),  # name
                        self.lineEdit_23.text(),  # source
                        self.plainTextEdit_7.toPlainText(),  # address
                        self.lineEdit_25.text(),  # place
                        self.plainTextEdit_8.toPlainText()]  # note
            if '' in entities:
                QMessageBox.warning(self, "Alert", "Enter all Data")
            else:
                if entry.files(entities):
                    QMessageBox.information(self, "Success", "Database added successfully")
                else:
                    QMessageBox.warning(self, "Failed", "Database adding is failed")

    def clearDatabaseWin(self):
        self.lineEdit_28.clear()  # name
        self.lineEdit_23.clear()  # source
        self.lineEdit_26.clear()  # phone
        self.lineEdit_27.clear()  # mail
        self.plainTextEdit_7.clear()  # address
        self.lineEdit_25.clear()  # place
        self.plainTextEdit_8.clear()
        self.comboBox_4.setCurrentIndex(0)
        self.comboBox_9.setCurrentIndex(0)
        self.comboBox_10.setCurrentIndex(0)

    def downloadDatabase(self):
        location = QFileDialog.getSaveFileName(self, caption="Save As", directory=".", filter="csv(*.csv*)")
        f = str(location[0])
        if QFileInfo(f).suffix() is '': f = f + '.csv'
        choice = self.comboBox_9.currentIndex()
        if choice is 0:
            QMessageBox.warning(self, "choose category", "You must choose category")
        elif choice is 1:
            records = entry.displayDetails('Anna University')
            with open(location[0], 'w') as o:
                o.write("ID, name, source, phone, mail, address, place, category, note\n")
                for record in records:
                    for item in record:
                        o.write(str(item) + ", ")
                    o.write('\n')
                o.close()
        elif choice is 2:
            records = entry.displayDetails('college')
            with open(location[0], 'w') as o:
                o.write("ID, name, source, phone, mail, address, place, category, note\n")
                for record in records:
                    for item in record:
                        o.write(str(item) + ", ")
                    o.write('\n')
                o.close()
        elif choice is 3:
            records = entry.displayDetails('company')
            with open(location[0], 'w') as o:
                o.write("ID, name, source, phone, mail, address, place, category, note\n")
                for record in records:
                    for item in record:
                        o.write(str(item) + ", ")
                    o.write('\n')
                o.close()
        elif choice is 4:
            records = entry.displayDetails('autvs')
            with open(location[0], 'w') as o:
                o.write("ID, name, source, phone, mail, address, place, category, note\n")
                for record in records:
                    for item in record:
                        o.write(str(item) + ", ")
                    o.write('\n')
                o.close()
        elif choice is 5:
            records = entry.displayDetails('file')
            with open(location[0], 'w') as o:
                o.write("ID, name, source, phone, mail, address, place, category, note\n")
                for record in records:
                    for item in record:
                        o.write(str(item) + ", ")
                    o.write('\n')
                o.close()
        elif choice is 6:
            records = entry.displayDetails('school')
            with open(location[0], 'w') as o:
                o.write("ID, name, source, phone, mail, address, place, category, note\n")
                for record in records:
                    for item in record:
                        o.write(str(item) + ", ")
                    o.write('\n')
                o.close()
        elif choice is 7:
            records = member.displayDetails()
            with open(location[0], 'w') as o:
                o.write("qid, name, rollno, department, dob, year, campus, residence, phone\n")
                for record in records:
                    for item in record:
                        o.write(str(item) + ", ")
                    o.write('\n')
                o.close()

    def importMailIds(self):
        choice = self.comboBox_10.currentIndex()
        if choice is 0:
            QMessageBox.warning(self, "choose category", "You must choose category")
        elif choice is 1:
            mails = entry.mailImport('Anna University')
            ids = ''
            for mail in mails:
                ids += str(mail[0]) + ", "
            self.plainTextEdit_2.setPlainText(ids)
        elif choice is 2:
            mails = entry.mailImport('college')
            ids = ''
            for mail in mails:
                ids += str(mail[0]) + ", "
            self.plainTextEdit_2.setPlainText(ids)
        elif choice is 3:
            mails = entry.mailImport('company')
            ids = ''
            for mail in mails:
                ids += str(mail[0]) + ", "
            self.plainTextEdit_2.setPlainText(ids)
        elif choice is 4:
            mails = entry.mailImport('autvs')
            ids = ''
            for mail in mails:
                ids += str(mail[0]) + ", "
            self.plainTextEdit_2.setPlainText(ids)
        elif choice is 5:
            mails = entry.mailImport('schools')
            ids = ''
            for mail in mails:
                ids += str(mail[0]) + ", "
            self.plainTextEdit_2.setPlainText(ids)
        self.tabWidget.setCurrentIndex(1)

    #######################TODO_APP#######################
    def todoData(self):
        entities = [self.lineEdit_16.text(),
                    self.lineEdit_19.text(),
                    self.lineEdit_20.text()]
        try:
            todo.insertData(entities)
            QMessageBox.information(self, "success", "Todo Enter successful")
        except:
            QMessageBox.warning(self, "Failure", "Todo enter unsuccessful")
        self.clearTodo()
        self.todoDisplay()

    def todoAction(self):
        action = self.comboBox_3.currentIndex()
        if action is 0:
            QMessageBox.warning(self, "Failure", "Todo enter unsuccessful")
        elif action is 1:
            # try:
            id = int(self.lineEdit_15.text())
            print(self.lineEdit_16.text())
            entities = [self.lineEdit_16.text(),
                        self.lineEdit_19.text(),
                        self.lineEdit_20.text()]
            if '' in entities:
                QMessageBox.warning(self, "Data Missing", "Enter data for update")
            else:
                if todo.updateData(id, entities):
                    QMessageBox.information(self, "success", "Todo Enter successful")
                else:
                    QMessageBox.warning(self, "Failure", "Todo enter unsuccessful")
        elif action is 2:
            self.todoData()
        elif action is 3:
            id = int(self.lineEdit_15.text())
            if id is '':
                QMessageBox.warning(self, "Data Missing", "Enter ID to Delete")
            else:
                if todo.deleteData(id):
                    QMessageBox.information(self, "success", "Todo Deleted successful")
                else:
                    QMessageBox.warning(self, "Failure", "Todo delete unsuccessful")
        elif action is 4:
            if todo.clearData():
                QMessageBox.information(self, "success", "Todos cleared successful")
            else:
                QMessageBox.warning(self, "Failure", "Todos clear unsuccessful")
        elif action is 5:
            QMessageBox.information(self, "Add soon", "This function will add soon")
        self.todoDisplay()
        self.clearTodo()

    def todoDisplay(self):
        values = todo.diplayData()
        table = self.tableWidget
        table.setRowCount(len(values))
        table.setColumnCount(5)

        for row, row_data in enumerate(values):
            for column, data in enumerate(row_data):
                table.setItem(row, column, QTableWidgetItem(str(data)))

    def clearTodo(self):
        pass

    #######################Money Manage#########################
    def enterData(self):
        name = self.lineEdit_11.text()
        try:
            money = int(self.lineEdit_14.text())
        except ValueError as v:
            QMessageBox.warning(self, "Value Error", str(v))
        remarks = self.plainTextEdit_3.toPlainText()
        if name is '' or money is '' or remarks is '':
            QMessageBox.warning(self, "Data Missing", "Enter all Data")
        else:
            choice = self.comboBox_2.currentIndex()
            if choice is 1:
                if account.addMoney(name, money, remarks) is True:
                    QMessageBox.information(self, "Success", "Money Added Successfully")
                    self.lcdNumber.display(account.balance())
                else:
                    QMessageBox.warning(self, "Sorry", "Money is't addd\n check issues of database")
            elif choice is 2:
                if account.withdrawMoney(name, money, remarks) is True:
                    QMessageBox.information(self, "Success", "Money withdraw Successfully")
                    self.lcdNumber.display(account.balance())
                else:
                    QMessageBox.warning(self, "Sorry", "Money is't withdraw\n check issues of database")
            elif choice is 0:
                QMessageBox.warning(self, "Choose Choice", "Choose to add/withdraw")
            self.clearMoney()

    def clearMoney(self):
        self.lineEdit_11.clear()
        self.lineEdit_14.clear()
        self.plainTextEdit_3.clear()

    def printHistory(self):
        try:
            location = QFileDialog.getSaveFileName(self, caption="Save As", directory=".", filter="csv(*.csv*)")
            f = str(location[0])
            if QFileInfo(f).suffix() is '': f = f + '.csv'
            records = account.printHistory()
            with open(location[0], 'w') as o:
                o.write("Date, Name, Withdraw, Deposit, Balance, Remarks\n")
                for record in records:
                    for r in record:
                        o.write(str(r) + ", ")
                    o.write('\n')
                o.close()
            QMessageBox.information(self, "Document saved", "Document saved successfully")
        except:
            QMessageBox.warning(self, "Sorry", "Doucument could'n Saved")

    ####################Membership##############################
    def membershipRegister(self):
        global entry
        try:
            entry = {0: self.lineEdit.text(), 1: int(self.lineEdit_2.text()), 2: self.lineEdit_3.text(),
                     4: int(self.lineEdit_8.text()), 5: self.lineEdit_7.text(), 3: self.dateEdit.text(),
                     7: int(self.lineEdit_17.text()), 8: self.lineEdit_18.text(), 9: self.lineEdit_13.text(),
                     10: self.lineEdit_12.text()}
            if self.comboBox.currentIndex() is 0:
                entry[6] = 'Hosteler'  # residence
            else:
                entry[6] = 'Dayscholor'
        except ValueError:
            QMessageBox.warning(self, "Value Error", "Year, RollNo, Phone No should be numbers only")
        if '' in entry:
            QMessageBox.warning(self, "Alert", "Enter all details")
        else:
            if member.newMembership(entry):
                QMessageBox.information(self, "successfully", "Registration Successfully")
                self.label_8.setText(member.qid)
                self.label_9.setPixmap(
                    QPixmap("idcards/" + entry[0] + "_" + member.qid + ".png").scaledToWidth(360).scaledToHeight(180))
                self.membershipSendMail()

            else:
                QMessageBox.warning(self, "Error", "Already Registered Roll No")

    def membershipSendMail(self):
        try:
            SUBJECT = "SQC Membership"
            MESSAGE = "Hello " + self.lineEdit.text() + ",\n\t Welcome to Students Quality council. You are now " \
                                                        "our family now "
            path = {'idcard.png': "idcards/" + self.lineEdit.text() + "_" + str(member.qid) + ".png",
                    'qrode.png': "qrode/" + self.lineEdit.text() + "_" + str(member.qid) + ".png", }
            SendingMail.SendEmail(str(self.lineEdit_18.text()), path, SUBJECT, MESSAGE)
            QMessageBox.information(self, "Mail Sent", "Mail Sent Success Fully")
        except:
            QMessageBox.warning(self, "Error", "Mail Could't sent")

    def membershipClear(self):
        self.lineEdit.setText('')  # name
        self.lineEdit_2.setText('')  # rollno
        self.lineEdit_3.setText('')  # department
        self.lineEdit_8.setText('')  # year
        self.lineEdit_7.setText('')  # campus
        # self.dateEdit.setDate(dat)  # dob
        self.label_9.clear()
        self.lineEdit_17.setText('')  # phone
        self.lineEdit_18.setText('')  # mail
        self.lineEdit_13.setText('')  # interest
        self.lineEdit_12.setText('')
        self.label_8.setText('')
        self.label_9.setText('')

    #############Sending Mail#######################
    def sendMails(self):
        SendingMail.USERNAME = self.lineEdit_4.text()
        SendingMail.PASSWORD = self.lineEdit_5.text()
        sub = self.lineEdit_6.text()
        msg = self.plainTextEdit.toPlainText()
        mails = str(self.plainTextEdit_2.toPlainText()).split(',')
        with open('LogFile.txt', 'w') as o:
            Success, Failure = '', ''
            for mail in mails:
                try:
                    SendingMail.SendEmail(str(mail), self.att, sub, msg)
                    self.listWidget_1.addItem(mail)
                    Success += mail + '\n'
                except:
                    self.listWidget_3.addItem(mail)
                    Failure += mail + '\n'
            o.write("Success\n%s\n\nFailure\n%s" % (Success, Failure))
            print("Success\n%s\n\nFailure\n%s" % (Success, Failure))

    def attachmentBrowse(self):
        attachment_location = QFileDialog.getOpenFileName(self, caption="Open", directory=".", filter="All files(*.*)")
        self.lineEdit_9.setText(str(attachment_location[0]))
        self.listWidget.addItem(str(attachment_location[0]))
        sps = str(attachment_location[0]).split('/')
        self.att[sps[-1]] = str(attachment_location[0])

    def clearMail(self):
        self.lineEdit_4.clear()
        self.lineEdit_5.clear()
        self.lineEdit_6.clear()
        self.lineEdit_4.clear()
        self.lineEdit_9.clear()
        self.plainTextEdit.clear()
        self.plainTextEdit_2.clear()
        self.listWidget.clear()
        self.listWidget_2.clear()
        self.listWidget_3.clear()

    def linkDetails_1(self):
        webbrowser.open('https://www.google.com/settings/security/lesssecureapps')

    def linkDetails_2(self):
        webbrowser.open('https://accounts.google.com/DisplayUnlockCaptcha')

    ##################################Attendance#################################
    def startAttendance(self):
        self.close = 0
        cap = cv2.VideoCapture(0)
        while True:
            _, frame = cap.read()
            decodedObjects = pyzbar.decode(frame)
            for obj in decodedObjects:
                if Attendence.checkData(int(obj.data)) is 1:
                    print(Attendence.present)
                    values = Attendence.present
                    for keys, val in values.items():
                        self.listWidget_4.addItem(str(val[0][0]) + "\t" + str(val[0][1]) + "\t" + str(val[0][2]) + "\t")
                        QMessageBox.information(self, "Confirm", "Hello\t" + str(val[0][1]))
                    Attendence.present = {}
                elif Attendence.checkData(int(obj.data)) is 2:
                    QMessageBox.warning(self, "Wrong QR Code", "Check You are Registered or Not")
                else:
                    QMessageBox.warning(self, "Already Present", "You are present already")
                time.sleep(1)
            cv2.imshow("Frame", frame)
            # closing the program when s is pressed
            if cv2.waitKey(1) & 0xFF == ord(' ') or self.close is 1:
                cv2.destroyAllWindows()
                break

    def closeCamera(self):
        cv2.destroyAllWindows()
        self.close = 1

    def typeQid(self):
        try:
            qid = self.lineEdit_10.text()
            if Attendence.checkData(qid) is 1:
                print(Attendence.present)
                values = Attendence.present
                for keys, val in values.items():
                    self.listWidget_4.addItem(str(val[0][0]) + "\t" + str(val[0][1]) + "\t" + str(val[0][2]) + "\t")
                    QMessageBox.information(self, "Confirm", "Hello  " + str(val[0][1]))
                Attendence.present = {}
            else:
                QMessageBox.warning(self, "Already Present", "You are present already")
            self.lineEdit_10.clear()
        except TypeError:
            QMessageBox.warning(self, "Type Error", "should type Numbers only")

    def printCSV(self):
        try:
            fn = QFileDialog.getSaveFileName(self, caption="Export File", directory='.', filter='CSV(.csv)')
            f = str(fn[0])
            if f != '':
                if QFileInfo(f).suffix() is '': f = f + '.csv'
                shutil.copyfile('attendence.csv', f)
            QMessageBox.information(self, "Successfully Saved", "File saved successfully")
        except:
            QMessageBox.warning(self, "Save Unsuccessful", "File could't saved")

    def resetAtt(self):
        try:
            Attendence.qids = []
            Attendence.present = {}
            with open('attendence.csv', 'w') as o:
                o.write("QID,Name,Department,Time\n")
            self.lineEdit_10.clear()
            self.listWidget_4.clear()
            QMessageBox.information(self, "Reset Successfully", "Attendance fully reset")

        except:
            QMessageBox.warning(self, "Reset Unsuccessful", "File could't reset")


def main():
    app = QApplication(sys.argv)
    window = MainApp()
    window.setWindowIcon(QIcon('logo.png'))
    window.setWindowTitle("Students Quality Council")
    window.setGeometry(QRect(150, 30, 950, 700))
    style = open('theme/dark', 'r')
    style = style.read()
    window.setStyleSheet(style)
    window.show()
    app.exec_()


if __name__ == '__main__':
    main()
